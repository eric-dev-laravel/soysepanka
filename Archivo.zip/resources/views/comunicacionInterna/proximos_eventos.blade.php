@extends('adminlte::layouts.app')

@section('htmlheader_title')
	{{ trans('message.ci.upcomingevents') }}
@endsection

@section('contentheader_title')
	{{ trans('message.ci.upcomingevents') }}
@endsection

@section('contentheader_level_here')
	{{ trans('message.ci.upcomingevents') }}
@endsection

@section('main-content')
@endsection


