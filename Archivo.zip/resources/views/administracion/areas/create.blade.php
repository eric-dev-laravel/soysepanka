@extends('adminlte::layouts.app')

@section('htmlheader_title')
	{{ trans('message.home') }}
@endsection

@section('contentheader_title')
	{{ trans('message.ma.admin_areas_title') }}
@endsection

@section('contentheader_level_here')
	{{ trans('message.ma.admin_areas_title') }}
@endsection

@section('main-content')
    @if($errors->any())
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                <h4><i class="icon fa fa-arrows"></i> {{ trans('message.modals.alert') }}</h4>
                {{ trans('message.modals.alert_message_createuser') }}

                <a href="#" class="small-box-footer pull-right" data-toggle="modal" data-target="#modal-danger">{{ trans('message.modals.moreinfo') }}</i></a>
            </div>

        </div>
    </div>
    @elseif(session()->has('success'))
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="alert alert-success alert-dismissible" id="success-alert">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                <h4><i class="icon fa fa-check"></i> {{ trans('message.modals.alert') }}</h4>
                {{ trans('message.modals.success_message') }}
            </div>
        </div>
    </div>
    @endif

    <div class="row">
        <div class="col-md-12">

            <div class="box">

                <div class="box-header with-border">
                    <h3 class="box-title"><i class="fa fa-pie-chart"></i> {{ trans('message.createarea') }}</h3>

                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                            <i class="fa fa-times"></i></button>
                    </div>
                </div>

                <div class="box-body">
                    <div class="row col-md-12">
                        <form role="form" method="POST" action="{{ route('admin-areas.store') }}" id="create">
                            {!! method_field('POST') !!}
                            {!! csrf_field() !!}

                            <div class="box box-primary">

                                <div class="box-header with-border">
                                    <h3 class="box-title"><i class="fa fa-pencil"></i> {{ trans('message.info_createarea') }}</h3>
                                </div>

                                <div class="box-body">

                                    {{--<div class="form-group col-md-6">
                                        <label for="id_enterprise">{{ trans('message.datatables_headers.enterprise') }}</label>
                                        <select class="form-control" id="id_enterprise" name="id_enterprise">
                                            <option value="">Sin Empresa</option>
                                            @foreach ($data['enterprises'] as $enterprise)
                                                <option value="{{ $enterprise->id }}">{{  $enterprise->name   }}</option>
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="id_enterprise">{{ trans('message.datatables_headers.mark') }}</label>
                                        <select class="form-control" id="id_mark" name="id_mark">
                                            <option value="">Sin Marca</option>
                                            @foreach ($data['marks'] as $mark)
                                                <option value="{{ $mark->id }}">{{  $mark->name   }}</option>
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="id_direction">{{ trans('message.datatables_headers.direction') }}</label>
                                        <select class="form-control" id="id_direction" name="id_direction">
                                            <option value="">Sin dirección</option>
                                            @foreach ($data['directions'] as $enterprise)
                                                <option value="{{ $enterprise->id }}">{{  $enterprise->name   }}</option>
                                            @endforeach
                                        </select>
                                    </div>--}}

                                    <div class="form-group col-md-12">
                                        <label for="nombre">{{ trans('message.datatables_headers.area') }}</label>
                                        <input type="text" required class="form-control" id="name" name="name" placeholder="{{ trans('message.form_employee_holder.area') }}">
                                    </div>

                                    <div class="form-group col-md-12">
                                        <label for="nombre">{{ trans('message.datatables_headers.description') }}</label>
                                        <textarea class="form-control" rows="4" id="description" name="description" placeholder="{{ trans('message.form_employee_holder.info_area') }}"></textarea>
                                    </div>

                                </div>

                                <div class="box-footer">
                                    <div class="row col-md-1 col-sm-12">
                                        <button type="button" onclick="window.location.href = '{{ url('admin-areas') }}';" class="btn btn-primary"><i class="fa fa-arrow-left"></i> {{ trans('message.buttons.back') }}</button>
                                    </div>
                                    <div class="row col-md-1 col-sm-12 col-md-offset-8">
                                        <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> {{ trans('message.buttons.create') }}</button>
                                    </div>
                                    <div class="row col-md-1 col-sm-12 col-md-offset-1">
                                        <button type="button" onclick="window.location.href = '{{ url('admin-areas') }}';" class="btn btn-danger"><i class="fa fa-ban"></i> {{ trans('message.buttons.cancel') }}</button>
                                    </div>
                                </div>

                            </div>

                        </form>
                    </div>
                </div>

            </div>
        </div>

        <div class="modal modal-danger fade" id="modal-danger" style="display: none;">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">{{ trans('message.modals.alert') }}</h4>
                    </div>

                    <div class="modal-body">
                        @if($errors->any())
                            <ul>
                                @foreach ($errors->all() as $message)
                                    <li>{{ $message }}</li>
                                @endforeach
                            </ul>
                        @endif
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">{{ trans('message.buttons.close') }}</button>
                    </div>
                </div>
            </div>
        </div>

    </div>

@endsection

@section('main-script')
    <script type="text/javascript">
        setTimeout(function() {
            $('#success-alert').fadeOut('fast');
        }, 5000); // <-- time in milliseconds

        //Combo Empresas
        /*$('#id_enterprise').change(function(){
            var id = $(this).val();
            getMarks(id);
        });

        function getMarks(id){
            $.ajax({
                url: "{{url('marks')}}/"+id,
                Type:'GET',
                success: function(result){

                    $('#id_mark').empty();
                    $('#id_mark').append($('<option>', {
                        value: '',
                        text : 'Sin Marca'
                    }));
                    $.each(result, function(i, item){
                        $('#id_mark').append($('<option>', {
                            value: item.id,
                            text : item.name
                        }));
                    })

                }
            });
        }

        //Combo Marcas
        $('#id_mark').change(function(){
            var id = $(this).val();
            getDirections(id);
        });

        function getDirections(id){
            $.ajax({
                url: "{{url('marks')}}/"+id,
                Type:'GET',
                success: function(result){

                    $('#id_direction').empty();
                    $('#id_direction').append($('<option>', {
                        value: '',
                        text : 'Sin Dirección'
                    }));
                    $.each(result, function(i, item){
                        $('#id_direction').append($('<option>', {
                            value: item.id,
                            text : item.name
                        }));
                    })

                }
            });
        }*/
    </script>
@endsection
