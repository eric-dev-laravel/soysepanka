
    <div class="row">

        <div class="col-md-12">
            <div class="callout callout-info">
                <h4>Próximamente!</h4>

                <p>Esta pestaña no se encuentra habilitada, consulte con el adminsitrador para mas información.</p>
            </div>
        </div>

    </div>
<?php /**PATH /Users/ericvargasrosas/Desktop/Laravel Projects/soysepanka/resources/views/expediente/partials/tab8.blade.php ENDPATH**/ ?>