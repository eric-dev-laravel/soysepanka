<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        <?php if(! Auth::guest()): ?>
            <div class="user-panel">
                <div class="pull-left image">
                    <?php if(empty($user->picture)): ?>
                        <img class="img-circle" src="<?php echo e(asset('img/record/user.png')); ?>" alt="User Avatar">
                    <?php else: ?>
                        <img class="img-circle" src="<?php echo e(asset($user->url_path)); ?>" alt="User Avatar">
                    <?php endif; ?>
                </div>
                <div class="pull-left info">
                    <p style="overflow: hidden;text-overflow: ellipsis;max-width: 160px;" data-toggle="tooltip" title="<?php echo e(Auth::user()->name); ?>"><?php echo e(Auth::user()->name); ?></p>
                    <!-- Status -->
                    <a href="#"><i class="fa fa-circle text-success"></i> <?php echo e(trans('message.online')); ?></a>
                </div>
            </div>
        <?php endif; ?>

        <!-- search form (Optional) -->
        <!--<form action="#" method="get" class="sidebar-form">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="<?php echo e(trans('message.search')); ?>..."/>
              <span class="input-group-btn">
                <button type='submit' name='search' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
        </form>-->
        <!-- /.search form -->

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header"><?php echo e(trans('message.header')); ?></li>
            <!-- Optionally, you can add icons to the links -->
            <li class="active"><a href="<?php echo e(url('home')); ?>"><i class='fa fa-home'></i> <span><?php echo e(trans('message.home')); ?></span></a></li>
            <!--<li><a href="#"><i class='fa fa-link'></i> <span><?php echo e(trans('message.anotherlink')); ?></span></a></li>-->

            <!-- Modulo0 Administración-->
            <li class="treeview">
                <a href="#"><i class='fa fa-cog'></i> <span><?php echo e(trans('message.module0')); ?></span> <i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(url('admin-users')); ?>"><i class='fa fa-user-plus'></i> <?php echo e(trans('message.ma.users')); ?></a></li>
                    <li><a href="<?php echo e(url('admin-employees')); ?>"><i class='fa fa-user-plus'></i> <?php echo e(trans('message.ma.employees')); ?></a></li>
                    <li><a href="<?php echo e(url('admin-jobpositionscatalog')); ?>"><i class='fa fa-book'></i> <?php echo e(trans('message.ma.jobpositioncatalog')); ?></a></li>
                    <li class="treeview" style="height: auto;">
                        <a href="#"><i class="fa fa-building"></i> <?php echo e(trans('message.ma.structure')); ?> <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
                        <ul class="treeview-menu" style="display: none;">
                            <li><a href="<?php echo e(url('admin-enterprises')); ?>"><i class='fa fa-university'></i> <?php echo e(trans('message.ma.company')); ?></a></li>
                            <li><a href="<?php echo e(url('admin-marks')); ?>"><i class='fa fa-bookmark'></i> <?php echo e(trans('message.ma.mark')); ?></a></li>
                            <li><a href="<?php echo e(url('admin-directions')); ?>"><i class='fa fa-arrows'></i> <?php echo e(trans('message.ma.direction')); ?></a></li>
                            <li><a href="<?php echo e(url('admin-areas')); ?>"><i class='fa fa-pie-chart'></i> <?php echo e(trans('message.ma.area')); ?></a></li>
                            <li><a href="<?php echo e(url('admin-departments')); ?>"><i class='fa fa-briefcase'></i> <?php echo e(trans('message.ma.department')); ?></a></li>
                            <li><a href="<?php echo e(url('admin-jobpositions')); ?>"><i class='fa fa-grav'></i> <?php echo e(trans('message.ma.jobposition')); ?></a></li>
                            
                        </ul>
                    </li>
                </ul>
            </li>

            <!-- Modulo1 Comunicacion Interna-->
            <li class="treeview">
                <a href="#"><i class='fa fa-comments'></i> <span><?php echo e(trans('message.module1')); ?></span> <i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(url('cumpleaños')); ?>"><i class='fa fa-birthday-cake'></i> <?php echo e(trans('message.ci.birthday')); ?></a></li>
                    <li><a href="<?php echo e(url('nuevos-ingresos')); ?>"><i class='fa fa-users'></i> <?php echo e(trans('message.ci.newrevenue')); ?></a></li>
                    <li><a href="#"><i class='fa fa-street-view'></i> <?php echo e(trans('message.ci.movementofpersonnel')); ?></a></li>
                    <li><a href="<?php echo e(url('quienes-somos')); ?>"><i class='fa fa-info'></i> <?php echo e(trans('message.ci.aboutus')); ?></a></li>
                    <li><a href="<?php echo e(url('organigrama')); ?>"><i class='fa fa-sitemap'></i> <?php echo e(trans('message.ci.organizationchart')); ?></a></li>
                    <li><a href="<?php echo e(url('politicas-reglamentos')); ?>"><i class='fa fa-book'></i> <?php echo e(trans('message.ci.regulations')); ?></a></li>
                    <li><a href="<?php echo e(url('infograficos')); ?>"><i class='fa fa-bookmark'></i> <?php echo e(trans('message.ci.infographics')); ?></a></li>
                    <li><a href="<?php echo e(url('galerias')); ?>"><i class='fa fa-camera-retro'></i> <?php echo e(trans('message.ci.galleries')); ?></a></li>
                    <li><a href="<?php echo e(url('proximos-eventos')); ?>"><i class='fa fa-calendar'></i> <?php echo e(trans('message.ci.upcomingevents')); ?></a></li>
                    <li><a href="<?php echo e(url('faqs')); ?>"><i class='fa fa-question'></i> <?php echo e(trans('message.ci.faqs')); ?></a></li>
                </ul>
            </li>

            <!-- Modulo2 Gestión de Vacantes-->
            <li class="treeview">
                <a href="#"><i class='fa fa-handshake-o'></i> <span><?php echo e(trans('message.module2')); ?></span> <i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                    <li><a href="#"><?php echo e(trans('message.linklevel2')); ?></a></li>
                </ul>
            </li>

            <!-- Modulo3 Evaluación del Desempeño-->
            <li class="treeview">
                <a href="#"><i class='fa fa-battery-2'></i> <span><?php echo e(trans('message.module3')); ?></span> <i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                    <li><a href="#"><?php echo e(trans('message.linklevel2')); ?></a></li>
                </ul>
            </li>

            <!-- Modulo4 Evaluación por Resultados-->
            <li class="treeview">
                <a href="#"><i class='fa fa-area-chart'></i> <span><?php echo e(trans('message.module4')); ?></span> <i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                    <li><a href="#"><?php echo e(trans('message.linklevel2')); ?></a></li>
                </ul>
            </li>

            <!-- Modulo5 Clima Laboral-->
            <li class="treeview">
                <a href="#"><i class='fa fa-thermometer'></i> <span><?php echo e(trans('message.module5')); ?></span> <i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                    <li><a href="#"><?php echo e(trans('message.linklevel2')); ?></a></li>
                </ul>
            </li>

            <!-- Modulo6 Control de Incidencias "vacaciones"-->
            <li class="treeview">
                <a href="#"><i class='fa fa-suitcase'></i> <span><?php echo e(trans('message.module6')); ?></span> <i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                    <li><a href="#"><?php echo e(trans('message.linklevel2')); ?></a></li>
                </ul>
            </li>

            <!-- Modulo7 Reconocimientos al Personal-->
            <li class="treeview">
                <a href="#"><i class='fa fa-star'></i> <span><?php echo e(trans('message.module7')); ?></span> <i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                    <li><a href="#"><?php echo e(trans('message.linklevel2')); ?></a></li>
                </ul>
            </li>

            <!-- Modulo8 Capacitación en Línea-->
            <li class="treeview">
                <a href="#"><i class='fa fa-graduation-cap'></i> <span><?php echo e(trans('message.module8')); ?></span> <i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                    <li><a href="#"><?php echo e(trans('message.linklevel2')); ?></a></li>
                </ul>
            </li>

            <!-- Modulo9 Herramientas-->
            <li class="treeview">
                <a href="#"><i class='fa fa-wrench'></i> <span><?php echo e(trans('message.module9')); ?></span> <i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                    <li><a href="#"><?php echo e(trans('message.linklevel2')); ?></a></li>
                </ul>
            </li>
        </ul><!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>
<?php /**PATH /Users/administrador/Desktop/Laravel Projects/soysepanka-adminlte/resources/views/vendor/adminlte/layouts/partials/sidebar.blade.php ENDPATH**/ ?>