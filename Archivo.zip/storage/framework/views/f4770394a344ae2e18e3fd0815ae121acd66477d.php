<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>Soysepanka</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
    <script src="https://kit.fontawesome.com/82ac0fb848.js" crossorigin="anonymous" ></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-bs4.css" rel="stylesheet">
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</head>
<body>
<div class="bg d-flex justify-content-center align-items-center">
    <div class="container">
        <div class="row d-flex justify-content-center align-items-center">
            <div class="card-container col-10 col-xs-10 col-sm-10 col-md-10 col-lg-5">
                <div class="card login-card animated zoomIn card-3">
                    <a href="<?php echo e(route('init')); ?>">
                        <div class="card-header card-header-log"></div>
                    </a>
                    <div class="card-body card-body-login">
                        <!--<form method="POST" action="moodle/login/index.php" aria-label="<?php echo e(__('Login')); ?>">-->
                        <!--<form method="POST" action="/moodle/login/index.php" aria-label="<?php echo e(__('Login')); ?>">-->
                        <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group row">
                                <!--<label for="email" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Correo:')); ?></label>-->

                                <div class="col-md-12">
                                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" placeholder="Nombre de usuario" value="<?php echo e(old('email')); ?>" required autofocus>
                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong class="text-white"><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <!--<label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Contraseña:')); ?></label>-->

                                <div class="col-md-12">
                                    <div class="input-group">

                                        <input id="password" placeholder="Contraseña" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                                        <div class="input-group-append">
                                            <button id="show_password" class="btn btn-primary" type="button" onclick="mostrarPassword()"> 
                                                <span class="fa fa-eye icon"></span> 
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong class="text-white"><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                    <div class="d-flex justify-content-end mt-2">
                                        <div class="form-group form-check">
                                            <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                            <label class="form-check-label" for="exampleCheck1">Recordar</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row my-2">
                                <div class="col text-center">
                                    <button type="submit" class="btn btn-success font-weight-bold card-1">
                                        <?php echo e(__('Iniciar ')); ?><i class="fas fa-sign-in-alt"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="form-group row my-2">
                                <div class="col text-center">
                                    <a class="btn btn-link text-white" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('¿Olvidaste tu contraseña?')); ?>

                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</html>
<script type="text/javascript">
function mostrarPassword(){
        var cambio = document.getElementById("password");
        if(cambio.type == "password"){
            cambio.type = "text";
            $('.icon').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
        }else{
            cambio.type = "password";
            $('.icon').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
        }
    } 
    
    $(document).ready(function () {
    //CheckBox mostrar contraseña
    $('#ShowPassword').click(function () {
        $('#Password').attr('type', $(this).is(':checked') ? 'text' : 'password');
    });
});
</script>
<?php /**PATH /Users/administrador/Desktop/Laravel Projects/soysepanka-adminlte/resources/views/vendor/adminlte/auth/login.blade.php ENDPATH**/ ?>