<?php $__env->startSection('htmlheader_title'); ?>
	<?php echo e(trans('message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
	<?php echo e(trans('message.ma.admin_employee_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_level_here'); ?>
	<?php echo e(trans('message.ma.admin_employee_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <?php if($errors->any()): ?>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                <h4><i class="icon fa fa-ban"></i> <?php echo e(trans('message.modals.alert')); ?></h4>
                <?php echo e(trans('message.modals.alert_message')); ?>


                <a href="#" class="small-box-footer pull-right" data-toggle="modal" data-target="#modal-danger"><?php echo e(trans('message.modals.moreinfo')); ?></i></a>
            </div>

        </div>
    </div>
    <?php elseif(session()->has('success')): ?>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="alert alert-success alert-dismissible" id="success-alert">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                <h4><i class="icon fa fa-check"></i> <?php echo e(trans('message.modals.alert')); ?></h4>
                <?php echo e(trans('message.modals.successupdate_message')); ?>

            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">

                <div class="box box-primary box-solid">

                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-hand-o-up"></i> <?php echo e(trans('message.options')); ?></h3>
                    </div>

                    <div class="box-body">

                        <div class="row col-md-3 col-sm-12 col-md-offset-2">
                            <?php if($data['employee'][0]->isUser): ?>
                                <button type="button" disabled class="btn btn-block btn-primary" onclick="window.location.href = '<?php echo e(url('create-user-from-employee/'.$data['employee'][0]->id.'')); ?>';"><i class="fa fa-key"></i> <?php echo e(trans('message.buttons.makeaccess')); ?></button>
                            <?php else: ?>
                                <button type="button" class="btn btn-block btn-primary" onclick="window.location.href = '<?php echo e(url('create-user-from-employee/'.$data['employee'][0]->id.'')); ?>';"><i class="fa fa-key"></i> <?php echo e(trans('message.buttons.makeaccess')); ?></button>
                            <?php endif; ?>
                        </div>

                        <div class="row col-md-3 col-sm-12 col-md-offset-2">
                            <?php if($data['employee'][0]->deleted_at): ?>
                                <button type="button" class="btn btn-block btn-success" data-toggle="modal" data-target="#modal-active-employee"><i class="fa fa-check-square"></i> <?php echo e(trans('message.buttons.active')); ?></button>
                            <?php else: ?>
                                <button type="button" class="btn btn-block btn-danger" data-toggle="modal" data-target="#modal-unactive-employee"><i class="fa fa-minus-square"></i> <?php echo e(trans('message.buttons.unactive')); ?></button>
                            <?php endif; ?>
                        </div>

                    </div>

                </div>

        </div>
    </div>

    <div class="row">

        <div class="col-md-12">

            <div class="box">

                <div class="box-header with-border">
                    <h3 class="box-title"><i class="fa fa-user"></i> <?php echo e(trans('message.editemployee')); ?></h3>

                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                            <i class="fa fa-times"></i></button>
                    </div>
                </div>

                <div class="box-body">
                    <div class="row col-md-12">
                        <form role="form" method="POST" action="<?php echo e(route('admin-employees.update',$data['employee'][0]->id)); ?>" id="update">
                            <?php echo method_field('PUT'); ?>

                            <?php echo csrf_field(); ?>


                            <div class="box box-primary">

                                <div class="box-header with-border">
                                    <h3 class="box-title"><i class="fa fa-pencil"></i> <?php echo e(trans('message.generalinfo')); ?></h3>
                                </div>

                                <div class="box-body">

                                    <div class="form-group col-md-4">
                                        <label for="nombre"><?php echo e(trans('message.datatables_headers.name')); ?></label>
                                        <input type="text" required class="form-control" id="nombre" name="nombre" value="<?php echo e($data['employee'][0]->nombre); ?>" placeholder="<?php echo trans('message.form_employee_holder.name'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="paterno"><?php echo e(trans('message.datatables_headers.paterno')); ?></label>
                                        <input type="text" required class="form-control" id="paterno" name="paterno" value="<?php echo e($data['employee'][0]->paterno); ?>" placeholder="<?php echo trans('message.form_employee_holder.paterno'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="materno"><?php echo e(trans('message.datatables_headers.materno')); ?></label>
                                        <input type="text" class="form-control" id="materno" name="materno" value="<?php echo e($data['employee'][0]->materno); ?>" placeholder="<?php echo trans('message.form_employee_holder.materno'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="rfc"><?php echo e(trans('message.datatables_headers.rfc')); ?></label>
                                        <input type="text" required class="form-control" id="rfc" name="rfc" value="<?php echo e($data['employee'][0]->rfc); ?>" placeholder="<?php echo trans('message.form_employee_holder.rfc'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="curp"><?php echo e(trans('message.datatables_headers.curp')); ?></label>
                                        <input type="text" class="form-control" id="curp" name="curp" value="<?php echo e($data['employee'][0]->curp); ?>" placeholder="<?php echo trans('message.form_employee_holder.curp'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="nss"><?php echo e(trans('message.datatables_headers.nss')); ?></label>
                                        <input type="text" class="form-control" id="nss" name="nss" value="<?php echo e($data['employee'][0]->nss); ?>" placeholder="<?php echo trans('message.form_employee_holder.nss'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="correopersonal"><?php echo e(trans('message.datatables_headers.personnel_mail')); ?></label>
                                        <input type="email" required class="form-control" id="correopersonal" name="correopersonal" value="<?php echo e($data['employee'][0]->correopersonal); ?>" placeholder="<?php echo trans('message.form_employee_holder.personnel_mail'); ?>"
                                        class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" autocomplete="email">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="nacimiento"><?php echo e(trans('message.datatables_headers.birth')); ?></label>
                                        <div class="input-group date">
                                            <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="date" class="form-control" id="nacimiento" name="nacimiento" value="<?php echo e($data['employee'][0]->nacimiento); ?>" placeholder="<?php echo trans('message.form_employee_holder.birth'); ?>">
                                        </div>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="sexo"><?php echo e(trans('message.datatables_headers.gender')); ?></label>
                                        <input type="text" class="form-control" id="sexo" name="sexo" value="<?php echo e($data['employee'][0]->sexo); ?>" placeholder="<?php echo trans('message.form_employee_holder.gender'); ?>">
                                    </div>

                                </div>

                            </div>

                            <div class="box box-warning">

                                <div class="box-header with-border">
                                    <h3 class="box-title"><i class="fa fa-pencil"></i> <?php echo e(trans('message.jobpositionInfo')); ?></h3>
                                </div>

                                <div class="box-body">
                                    <div class="form-group col-md-12">
                                        <label for="puesto"><?php echo e(trans('message.datatables_headers.position')); ?></label>
                                        
                                        <select class="form-control" id="puesto" name="puesto">
                                            <option value=""><?php echo e(trans('message.datatables_headers.outjobposition')); ?></option>
                                            <?php $__currentLoopData = $data['list_jobpositions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $enterprise = "Sin Empresa";
                                                    $mark = "Sin Marca";
                                                    $direction = "Sin Dirección";
                                                    $area = "Sin Área";
                                                    $department = "Sin Departamento";
                                                    if(!empty($position->enterprise->name))
                                                        $enterprise = $position->enterprise->name;
                                                    if(!empty($position->mark->name))
                                                        $mark = $position->mark->name;
                                                    if(!empty($position->direction->name))
                                                        $direction = $position->direction->name;
                                                    if(!empty($position->area->name))
                                                        $area = $position->area->name;
                                                    if(!empty($position->department->name))
                                                        $department = $position->department->name;
                                                ?>

                                                <?php if($position->name == $data['employee'][0]->puesto && $position->department->name == $data['employee'][0]->departamento): ?>
                                                    <option selected value="<?php echo e($position->id.','.$enterprise.','.$mark.','.$direction.','.$area.','.$department.','.$position->name); ?>"><?php echo e($enterprise.' / '.$mark.' / '.$direction.' / '.$area.' / '.$department.' / '.$position->name); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($position->id.','.$enterprise.','.$mark.','.$direction.','.$area.','.$department.','.$position->name); ?>"><?php echo e($enterprise.' / '.$mark.' / '.$direction.' / '.$area.' / '.$department.' / '.$position->name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-12">
                                        <label for="jefe"><?php echo e(trans('message.datatables_headers.boss')); ?></label>
                                        <select class="form-control" id="jefe" name="jefe">
                                            <option value=""><?php echo e(trans('message.datatables_headers.outboss')); ?></option>
                                            <?php $__currentLoopData = $data['bosses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($boss->idempleado == $data['employee'][0]->jefe): ?>
                                                    <option selected value="<?php echo e($boss->idempleado); ?>"><?php echo e($boss->nombre.' '.$boss->paterno.' '.$boss->materno); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($boss->idempleado); ?>"><?php echo e($boss->nombre.' '.$boss->paterno.' '.$boss->materno); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="idempresa"><?php echo e(trans('message.datatables_headers.enterprise_id')); ?></label>
                                        <input type="text" disabled class="form-control" id="idempresa" name="idempresa" value="<?php echo e($data['employee'][0]->idempresa); ?>" placeholder="<?php echo trans('message.form_employee_holder.enterprise_id'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="empresa"><?php echo e(trans('message.datatables_headers.enterprise')); ?></label>
                                        <input type="text" disabled class="form-control" id="empresa" name="empresa" value="<?php echo e($data['employee'][0]->empresa); ?>" placeholder="<?php echo trans('message.form_employee_holder.enterprise'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="marca"><?php echo e(trans('message.datatables_headers.mark')); ?></label>
                                        <input type="text" disabled class="form-control" id="marca" name="marca" value="<?php echo e($data['employee'][0]->marca); ?>" placeholder="<?php echo trans('message.form_employee_holder.mark'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="direccion"><?php echo e(trans('message.datatables_headers.direction')); ?></label>
                                        <input type="text" disabled class="form-control" id="direccion" name="direccion" value="<?php echo e($data['employee'][0]->direccion); ?>" placeholder="<?php echo trans('message.form_employee_holder.direction'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="seccion"><?php echo e(trans('message.datatables_headers.section').' / '.trans('message.datatables_headers.area')); ?></label>
                                        <input type="text" disabled class="form-control" id="seccion" name="seccion" value="<?php echo e($data['employee'][0]->seccion); ?>" placeholder="<?php echo trans('message.form_employee_holder.section'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="departamento"><?php echo e(trans('message.datatables_headers.department')); ?></label>
                                        <input type="text" disabled class="form-control" id="departamento" name="departamento" value="<?php echo e($data['employee'][0]->departamento); ?>" placeholder="<?php echo trans('message.form_employee_holder.department'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="division"><?php echo e(trans('message.datatables_headers.division')); ?></label>
                                        <input type="text" class="form-control" id="division" name="division" value="<?php echo e($data['employee'][0]->division); ?>" placeholder="<?php echo trans('message.form_employee_holder.division'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="region"><?php echo e(trans('message.datatables_headers.region')); ?></label>
                                        <input type="text" class="form-control" id="region" name="region" value="<?php echo e($data['employee'][0]->region); ?>" placeholder="<?php echo trans('message.form_employee_holder.region'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="sucursal"><?php echo e(trans('message.datatables_headers.subsidiary')); ?></label>
                                        <input type="text" class="form-control" id="sucursal" name="sucursal" value="<?php echo e($data['employee'][0]->sucursal); ?>" placeholder="<?php echo trans('message.form_employee_holder.subsidiary'); ?>">
                                    </div>

                                </div>

                            </div>

                            <div class="box box-warning">

                                <div class="box-header with-border">
                                    <h3 class="box-title"><i class="fa fa-building"></i> <?php echo e(trans('message.additional_jobposition')); ?></h3>
                                </div>

                                <div class="box-body">
                                    <div class="form-group col-md-11">
                                        <label for="puesto"><?php echo e(trans('message.datatables_headers.position')); ?></label>
                                        <select class="form-control" id="puesto_adicional" name="puesto_adicional">
                                            <option value=""><?php echo e(trans('message.datatables_headers.outjobposition')); ?></option>
                                            <?php $__currentLoopData = $data['list_jobpositions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $enterprise = "Sin Empresa";
                                                    $mark = "Sin Marca";
                                                    $direction = "Sin Dirección";
                                                    $area = "Sin Área";
                                                    $department = "Sin Departamento";
                                                    if(!empty($position->enterprise->name))
                                                        $enterprise = $position->enterprise->name;
                                                    if(!empty($position->mark->name))
                                                        $mark = $position->mark->name;
                                                    if(!empty($position->direction->name))
                                                        $direction = $position->direction->name;
                                                    if(!empty($position->area->name))
                                                        $area = $position->area->name;
                                                    if(!empty($position->department->name))
                                                        $department = $position->department->name;
                                                ?>

                                                <option value="<?php echo e($position->id. ' , ' .$enterprise.' , '.$mark.' , '.$direction.' , '.$area.' , '.$department.' , '.$position->name); ?>"><?php echo e($enterprise.' / '.$mark.' / '.$direction.' / '.$area.' / '.$department.' / '.$position->name); ?></option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-1">
                                        <label for="spoken">Agregar:</label>
                                        <button type="button" class="btn btn-success" id="add_aditional_jobposition">
                                            <span class="fa fa-plus"></span>
                                        </button>
                                    </div>

                                    <div class="form-group col-md-12" id="aditional_jobposition_div_c"></div>

                                </div>

                            </div>

                            <div class="box box-warning">

                                <div class="box-header with-border">
                                    <h3 class="box-title"><i class="fa fa-pencil"></i> <?php echo e(trans('message.jobpositionInfo')); ?></h3>
                                </div>

                                <div class="box-body">

                                    <div class="form-group col-md-4">
                                        <label for="idempleado"><?php echo e(trans('message.datatables_headers.idemployee')); ?></label>
                                        <input type="text" required class="form-control" id="idempleado" name="idempleado" value="<?php echo e($data['employee'][0]->idempleado); ?>" placeholder="<?php echo trans('message.form_employee_holder.idemployee'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="fuente"><?php echo e(trans('message.datatables_headers.origin')); ?></label>
                                        <input type="text" required class="form-control" id="fuente" name="fuente" value="<?php echo e($data['employee'][0]->fuente); ?>" placeholder="<?php echo trans('message.form_employee_holder.origin'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="correoempresa"><?php echo e(trans('message.datatables_headers.enterprise_mail')); ?></label>
                                        <input type="email" class="form-control" id="correoempresa" name="correoempresa" value="<?php echo e($data['employee'][0]->correoempresa); ?>" placeholder="<?php echo trans('message.form_employee_holder.enterprise_mail'); ?>"
                                        class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" autocomplete="email">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="civil"><?php echo e(trans('message.datatables_headers.state')); ?></label>
                                        <input type="text" class="form-control" id="civil" name="civil" value="<?php echo e($data['employee'][0]->civil); ?>" placeholder="<?php echo trans('message.form_employee_holder.state'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="telefono"><?php echo e(trans('message.datatables_headers.phone')); ?></label>
                                        <input type="text" class="form-control" id="telefono" name="telefono" value="<?php echo e($data['employee'][0]->telefono); ?>" placeholder="<?php echo trans('message.form_employee_holder.phone'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="extension"><?php echo e(trans('message.datatables_headers.ext')); ?></label>
                                        <input type="text" class="form-control" id="extension" name="extension" value="<?php echo e($data['employee'][0]->extension); ?>" placeholder="<?php echo trans('message.form_employee_holder.ext'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="celular"><?php echo e(trans('message.datatables_headers.movil')); ?></label>
                                        <input type="text" class="form-control" id="celular" name="celular" value="<?php echo e($data['employee'][0]->celular); ?>" placeholder="<?php echo trans('message.form_employee_holder.movil'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="ingreso"><?php echo e(trans('message.datatables_headers.entry')); ?></label>
                                        <div class="input-group date">
                                            <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="date" class="form-control" id="ingreso" name="ingreso" value="<?php echo e($data['employee'][0]->ingreso); ?>" placeholder="<?php echo trans('message.form_employee_holder.entry'); ?>">
                                        </div>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="fechapuesto"><?php echo e(trans('message.datatables_headers.date_position')); ?></label>
                                        <div class="input-group date">
                                            <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="date" class="form-control" id="fechapuesto" name="fechapuesto" value="<?php echo e($data['employee'][0]->fechapuesto); ?>" placeholder="<?php echo trans('message.form_employee_holder.date_position'); ?>">
                                        </div>
                                    </div>

                                    

                                    <div class="form-group col-md-4">
                                        <label for="grado"><?php echo e(trans('message.datatables_headers.grade')); ?></label>
                                        <input type="text" class="form-control" id="grado" name="grado" value="<?php echo e($data['employee'][0]->grado); ?>" placeholder="<?php echo trans('message.form_employee_holder.grade'); ?>">
                                    </div>

                                    

                                    <div class="form-group col-md-4">
                                        <label for="centro"><?php echo e(trans('message.datatables_headers.center')); ?></label>
                                        <input type="text" class="form-control" id="centro" name="centro" value="<?php echo e($data['employee'][0]->centro); ?>" placeholder="<?php echo trans('message.form_employee_holder.center'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="checador"><?php echo e(trans('message.datatables_headers.timer')); ?></label>
                                        <input type="text" class="form-control" id="checador" name="checador" value="<?php echo e($data['employee'][0]->checador); ?>" placeholder="<?php echo trans('message.form_employee_holder.timer'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="turno"><?php echo e(trans('message.datatables_headers.turn')); ?></label>
                                        <input type="text" class="form-control" id="turno" name="turno" value="<?php echo e($data['employee'][0]->turno); ?>" placeholder="<?php echo trans('message.form_employee_holder.turn'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="tiponomina"><?php echo e(trans('message.datatables_headers.payroll_type')); ?></label>
                                        <input type="text" class="form-control" id="tiponomina" name="tiponomina" value="<?php echo e($data['employee'][0]->tiponomina); ?>" placeholder="<?php echo trans('message.form_employee_holder.payroll_type'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="clavenomina"><?php echo e(trans('message.datatables_headers.payroll_id')); ?></label>
                                        <input type="text" class="form-control" id="clavenomina" name="clavenomina" value="<?php echo e($data['employee'][0]->clavenomina); ?>" placeholder="<?php echo trans('message.form_employee_holder.payroll_id'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="nombrenomina"><?php echo e(trans('message.datatables_headers.payroll_name')); ?></label>
                                        <input type="text" class="form-control" id="nombrenomina" name="nombrenomina" value="<?php echo e($data['employee'][0]->nombrenomina); ?>" placeholder="<?php echo trans('message.form_employee_holder.payroll_name'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="generalista"><?php echo e(trans('message.datatables_headers.generalist')); ?></label>
                                        <input type="text" class="form-control" id="generalista" name="generalista" value="<?php echo e($data['employee'][0]->generalista); ?>" placeholder="<?php echo trans('message.form_employee_holder.generalist'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="relacion"><?php echo e(trans('message.datatables_headers.association')); ?></label>
                                        <input type="text" class="form-control" id="relacion" name="relacion" value="<?php echo e($data['employee'][0]->relacion); ?>" placeholder="<?php echo trans('message.form_employee_holder.association'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="contrato"><?php echo e(trans('message.datatables_headers.contract')); ?></label>
                                        <input type="text" class="form-control" id="contrato" name="contrato" value="<?php echo e($data['employee'][0]->contrato); ?>" placeholder="<?php echo trans('message.form_employee_holder.contract'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="horario"><?php echo e(trans('message.datatables_headers.schedule')); ?></label>
                                        <input type="text" class="form-control" id="horario" name="horario" value="<?php echo e($data['employee'][0]->horario); ?>" placeholder="<?php echo trans('message.form_employee_holder.schedule'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="jornada"><?php echo e(trans('message.datatables_headers.working_day')); ?></label>
                                        <input type="text" class="form-control" id="jornada" name="jornada" value="<?php echo e($data['employee'][0]->jornada); ?>" placeholder="<?php echo trans('message.form_employee_holder.working_day'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="calculo"><?php echo e(trans('message.datatables_headers.calculation')); ?></label>
                                        <input type="text" class="form-control" id="calculo" name="calculo" value="<?php echo e($data['employee'][0]->calculo); ?>" placeholder="<?php echo trans('message.form_employee_holder.calculation'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="vacaciones"><?php echo e(trans('message.datatables_headers.vacations')); ?></label>
                                        <input type="text" class="form-control" id="vacaciones" name="vacaciones" value="<?php echo e($data['employee'][0]->vacaciones); ?>" placeholder="<?php echo trans('message.form_employee_holder.vacations'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="flotante"><?php echo e(trans('message.datatables_headers.float')); ?></label>
                                        <input type="text" class="form-control" id="flotante" name="flotante" value="<?php echo e($data['employee'][0]->flotante); ?>" placeholder="<?php echo trans('message.form_employee_holder.float'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="base"><?php echo e(trans('message.datatables_headers.base')); ?></label>
                                        <input type="text" class="form-control" id="base" name="base" value="<?php echo e($data['employee'][0]->base); ?>" placeholder="<?php echo trans('message.form_employee_holder.base'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="rol"><?php echo e(trans('message.datatables_headers.role')); ?></label>
                                        <input type="text" class="form-control" id="rol" name="rol" value="<?php echo e($data['employee'][0]->rol); ?>" placeholder="<?php echo trans('message.form_employee_holder.role'); ?>">
                                    </div>

                                </div>

                            </div>

                            <div class="box box-danger">

                                <div class="box-header with-border">
                                    <h3 class="box-title"><i class="fa fa-pencil"></i> <?php echo e(trans('message.personnelinfo_extra')); ?></h3>
                                </div>

                                <div class="box-body">

                                    <div class="form-group col-md-4">
                                        <label for="extra1"><?php echo e(trans('message.datatables_headers.extra1')); ?></label>
                                        <input type="text" class="form-control" id="extra1" name="extra1" value="<?php echo e($data['employee'][0]->extra1); ?>" placeholder="<?php echo trans('message.form_employee_holder.extra1'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="extra2"><?php echo e(trans('message.datatables_headers.extra2')); ?></label>
                                        <input type="text" class="form-control" id="extra2" name="extra2" value="<?php echo e($data['employee'][0]->extra2); ?>" placeholder="<?php echo trans('message.form_employee_holder.extra2'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="extra3"><?php echo e(trans('message.datatables_headers.extra3')); ?></label>
                                        <input type="text" class="form-control" id="extra3" name="extra3" value="<?php echo e($data['employee'][0]->extra3); ?>" placeholder="<?php echo trans('message.form_employee_holder.extra3'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="extra4"><?php echo e(trans('message.datatables_headers.extra4')); ?></label>
                                        <input type="text" class="form-control" id="extra4" name="extra4" value="<?php echo e($data['employee'][0]->extra4); ?>" placeholder="<?php echo trans('message.form_employee_holder.extra4'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="extra5"><?php echo e(trans('message.datatables_headers.extra5')); ?></label>
                                        <input type="text" class="form-control" id="extra5" name="extra5" value="<?php echo e($data['employee'][0]->extra5); ?>" placeholder="<?php echo trans('message.form_employee_holder.extra5'); ?>">
                                    </div>

                                </div>

                                <div class="box-footer">
                                    <div class="row col-md-1 col-sm-12">
                                        <button type="button" onclick="window.location.href = '<?php echo e(url('admin-employees')); ?>';" class="btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(trans('message.buttons.back')); ?></button>
                                    </div>
                                    <div class="row col-md-1 col-sm-12 col-md-offset-8">
                                        <button type="submit" class="btn btn-success"><i class="fa fa-refresh"></i> <?php echo e(trans('message.buttons.update')); ?></button>
                                    </div>
                                    <div class="row col-md-1 col-sm-12 col-md-offset-1">
                                        <button type="button" onclick="window.location.href = '<?php echo e(url('admin-employees')); ?>';" class="btn btn-danger"><i class="fa fa-ban"></i> <?php echo e(trans('message.buttons.cancel')); ?></button>
                                    </div>
                                </div>

                            </div>

                        </form>
                    </div>
                </div>

            </div>
        </div>

        <div class="modal modal-danger fade" id="modal-danger" style="display: none;">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title"><?php echo e(trans('message.modals.alert')); ?></h4>
                    </div>

                    <div class="modal-body">
                        <?php if($errors->any()): ?>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline pull-left" data-dismiss="modal"><?php echo e(trans('message.buttons.close')); ?></button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal modal-danger fade" id="modal-unactive-employee" style="display: none;">
            <form class="form" action="<?php echo e(route('admin-employees.destroy' , $data['employee'][0]->id)); ?>" method="POST">
                <?php echo method_field('DELETE'); ?>

                <?php echo csrf_field(); ?>

                <div class="modal-dialog">
                    <div class="modal-content">

                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                            <h4 class="modal-title"><?php echo e(trans('message.modals.alert')); ?></h4>
                        </div>

                        <div class="modal-body">
                            <?php echo e(trans('message.modals.dangermessageemployee')); ?>

                            <?php echo e(trans('message.modals.questioncontinue')); ?>

                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline pull-left" data-dismiss="modal"><?php echo e(trans('message.buttons.close')); ?></button>
                            <button type="submit" class="btn btn-outline"><?php echo e(trans('message.buttons.unactive')); ?></button>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <div class="modal modal-success fade" id="modal-active-employee" style="display: none;">
                <div class="modal-dialog">
                    <div class="modal-content">

                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                            <h4 class="modal-title"><?php echo e(trans('message.modals.alert')); ?></h4>
                        </div>

                        <div class="modal-body">
                            <?php echo e(trans('message.modals.warningmessageemployee')); ?>

                            <?php echo e(trans('message.modals.questioncontinue')); ?>

                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline pull-left" data-dismiss="modal"><?php echo e(trans('message.buttons.close')); ?></button>
                            <button type="button" onclick="window.location.href = '<?php echo e(url('active-employee/'.$data['employee'][0]->id.'')); ?>';" class="btn btn-outline"><?php echo e(trans('message.buttons.active')); ?></button>
                        </div>
                    </div>
                </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-script'); ?>
    <script type="text/javascript">
        setTimeout(function() {
            $('#success-alert').fadeOut('fast');
        }, 5000); // <-- time in milliseconds

        $(document).ready(function(){
            var id = $('#puesto').val();
            var index = id.split(',');
            var jobPosition = index[6];
            var department = index[5];
            getInfoJobPosition(jobPosition, department);
        });

        $('#puesto').change(function(){
            var id = $(this).val();
            var index = id.split(',');
            var jobPosition = index[6];
            var department = index[5];
            getBoss(jobPosition, department);
        });

        function getBoss(id, id_department){
            $.ajax({
                url: "<?php echo e(url('bosses')); ?>/"+id+"/"+id_department,
                Type:'GET',
                success: function(result){
                    console.log(id_department);
                    $('#jefe').empty();
                    document.getElementById('idempresa').value = '';
                    document.getElementById('empresa').value = '';
                    document.getElementById('marca').value = '';
                    document.getElementById('direccion').value = '';
                    document.getElementById('seccion').value = '';
                    document.getElementById('departamento').value = '';

                    $('#jefe').append($('<option>', {
                        value: '',
                        text : 'Sin Jefe'
                    }));
                    $.each(result['bosses'], function(i, item){
                        console.log(item);
                        $('#jefe').append($('<option>', {
                            value: item.idempleado,
                            text : item.nombre+' '+item.paterno+' '+item.materno
                        }));
                    });

                    document.getElementById('idempresa').value = result['id_enterprise'];
                    document.getElementById('empresa').value = result['enterprise'];
                    document.getElementById('marca').value = result['mark'];
                    document.getElementById('direccion').value = result['direction'];
                    document.getElementById('seccion').value = result['area'];
                    document.getElementById('departamento').value = result['department'];

                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    $('#jefe').empty();
                    document.getElementById('idempresa').value = '';
                    document.getElementById('empresa').value = '';
                    document.getElementById('marca').value = '';
                    document.getElementById('direccion').value = '';
                    document.getElementById('seccion').value = '';
                    document.getElementById('departamento').value = '';
                }
            });
        }

        function getInfoJobPosition(id, id_department){
            $.ajax({
                url: "<?php echo e(url('bosses')); ?>/"+id+"/"+id_department,
                Type:'GET',
                success: function(result){
                    document.getElementById('idempresa').value = '';
                    document.getElementById('empresa').value = '';
                    document.getElementById('marca').value = '';
                    document.getElementById('direccion').value = '';
                    document.getElementById('seccion').value = '';
                    document.getElementById('departamento').value = '';

                    document.getElementById('idempresa').value = result['id_enterprise'];
                    document.getElementById('empresa').value = result['enterprise'];
                    document.getElementById('marca').value = result['mark'];
                    document.getElementById('direccion').value = result['direction'];
                    document.getElementById('seccion').value = result['area'];
                    document.getElementById('departamento').value = result['department'];

                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    $('#jefe').empty();
                    document.getElementById('idempresa').value = '';
                    document.getElementById('empresa').value = '';
                    document.getElementById('marca').value = '';
                    document.getElementById('direccion').value = '';
                    document.getElementById('seccion').value = '';
                    document.getElementById('departamento').value = '';
                }
            });
        }

        /* ----------------------------------------
        * Agregar renglones a los idiomas cada que se presiona
        * el botón agregar y mostrarlos debajo
        * y también la función de eliminar el renglón
        * -------------------------------------------
        */
        var additional_jobposition = [];

        /*
        Validamos si ya existen datos guardados
        */
        <?php if(isset($data['additional_jobposition'])): ?>
            language = <?php echo json_encode($data['additional_jobposition']); ?>;
            $.each(language, function(i, item) {
                inputAdditionalJobPosition  = '<div class="form-group col-md-11"><input type="text" name="additional_jobpositon[]" value="'+item+'" class="form-control" readonly="true"></div>';
                deleteRow         = '<div class="form-group col-md-1"><button type="button" class="btn btn-danger" id="borrar"><span class="fa fa-minus"></span></button></div>';
                $('#aditional_jobposition_div_c').append('<div class="row">'+inputAdditionalJobPosition+deleteRow+'</div>');
            });
        <?php endif; ?>

        $('#add_aditional_jobposition').on('click',  function(e) {
            e.preventDefault();

            additional_jobposition.push($('#puesto_adicional').val());


            var lastAdditionalJobPosition = additional_jobposition[additional_jobposition.length-1];

            inputAdditionalJobPosition = '<div class="form-group col-md-11"><input type="text" name="additional_jobpositon[]" value="'+lastAdditionalJobPosition+'" class="form-control" readonly="true"></div>';
            deleteRow               = '<div class="form-group col-md-1"><button type="button" class="btn btn-danger" id="borrar"><span class="fa fa-minus"></span></button></div>';
            $('#aditional_jobposition_div_c').append('<div class="row">'+inputAdditionalJobPosition+deleteRow+'</div>');

            $('#puesto_adicional').val('');
        });

        /* ----------------------------------------
            * eliminar renglón de escolaridad
            * ----------------------------------------
        */
        $("#aditional_jobposition_div_c").on('click', '#borrar',function(e) {
            e.preventDefault();
            $(this).parent().parent().remove();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ericvargasrosas/Desktop/Laravel Projects/soysepanka/resources/views/administracion/employees/edit.blade.php ENDPATH**/ ?>