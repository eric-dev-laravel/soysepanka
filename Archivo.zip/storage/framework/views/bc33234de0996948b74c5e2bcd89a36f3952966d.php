<div class="row">

    <div class="col-md-12">
        <div class="col-md-3">

            <div class="col-md-12">
                <?php if(empty($data['records_info'][0]->picture)): ?>
                    <img class="img-circle" src="<?php echo e(asset('img/record/user.png')); ?>" alt="User Avatar" style="max-height: 222px;">
                <?php else: ?>
                    <img class="img-circle" src="<?php echo e(asset($data['records_info'][0]->url_path)); ?>" alt="User Avatar" style="max-height: 222px;">
                <?php endif; ?>
            </div>

        </div>
        <div class="col-md-8">
            <div class="form-group col-xs-6 col-md-4">
                <?php echo e(trans('message.datatables_headers.name')); ?><br />
                <label for="nombre" style="font-size: 17px"> <?php echo e($data['employee_info'][0]->nombre); ?> </label>
            </div>

            <div class="form-group col-xs-6 col-md-4">
                <?php echo e(trans('message.datatables_headers.paterno')); ?><br />
                <label for="nombre" style="font-size: 17px"> <?php echo e($data['employee_info'][0]->paterno); ?> </label>
            </div>

            <div class="form-group col-xs-6 col-md-4">
                <?php echo e(trans('message.datatables_headers.materno')); ?><br />
                <label for="nombre" style="font-size: 17px"> <?php echo e($data['employee_info'][0]->materno); ?> </label>
            </div>

            <div class="form-group col-xs-6 col-md-4">
                <?php echo e(trans('message.ex.phone_number')); ?><br />
                <label for="nombre" style="font-size: 17px"> <?php echo e($data['employee_info'][0]->celular); ?> </label>
            </div>

            <div class="form-group col-xs-6 col-md-4">
                <?php echo e(trans('message.ex.home_number')); ?><br />
                <label for="nombre" style="font-size: 17px"> <?php echo e($data['employee_info'][0]->telefono); ?> </label>
            </div>

            <div class="form-group col-xs-6 col-md-4">
                <?php echo e(trans('message.ex.email')); ?><br />
                <label for="nombre" style="font-size: 17px"> <?php echo e($data['employee_info'][0]->correoempresa); ?> </label>
            </div>

            <div class="form-group col-xs-6 col-md-4">
                <?php echo e(trans('message.ex.gender')); ?><br />
                <label for="nombre" style="font-size: 17px"> <?php echo e($data['employee_info'][0]->sexo); ?> </label>
            </div>

            <div class="form-group col-xs-6 col-md-4">
                <?php echo e(trans('message.ex.birthday')); ?><br />
                <label for="nombre" style="font-size: 17px"> <?php echo e($data['employee_info'][0]->nacimiento); ?> </label>
            </div>

            <div class="form-group col-xs-6 col-md-4">
                <?php echo e(trans('message.ex.rfc')); ?><br />
                <label for="nombre" style="font-size: 17px"> <?php echo e($data['employee_info'][0]->rfc); ?> </label>
            </div>

        </div>
    </div>

</div>

<div class="row">
    <form method="post" id="updateProfileHealth" action="<?php echo e(url('records-update-health/'.$data['employee_info'][0]->id)); ?>" enctype="multipart/form-data" autocomplete="off">
        <?php echo csrf_field(); ?>

    
    <div class="col-md-12">
        <div class="box box-primary">

            <div class="box-header with-border">
                <h3 class="box-title"><i class="fa fa-heartbeat"></i> <?php echo e(trans('message.ex.health_data_title')); ?></h3>
            </div>

            <div class="box-body">

                <div class="form-group col-md-12">

                    <div class="form-group col-md-6">
                        <label for="language"><?php echo e(trans('message.ex.nss')); ?></label>
                        <?php if(empty($data['records_info'][0]->nss)): ?>
                            <input type="text" name="health_nss_c" id="health_nss" class="form-control">
                        <?php else: ?>
                            <input type="text" name="health_nss_c" id="health_nss" value="<?php echo e($data['records_info'][0]->nss); ?>" class="form-control">
                        <?php endif; ?>
                    </div>

                    <div class="form-group col-md-6">
                        <label for="language"><?php echo e(trans('message.ex.blood')); ?></label>
                        <?php if(empty($data['records_info'][0]->blood)): ?>
                            <input type="text" name="health_blood_c" id="health_blood" class="form-control">
                        <?php else: ?>
                            <input type="text" name="health_blood_c" id="health_blood" value="<?php echo e($data['records_info'][0]->blood); ?>" class="form-control">
                        <?php endif; ?>
                    </div>

                    <div class="form-group col-md-12">
                        <label for="nombre"><?php echo e(trans('message.ex.diseases')); ?></label>
                        <?php if(empty($data['records_info'][0]->diseases)): ?>
                            <textarea class="form-control" rows="4" id="health_diseases_c" name="health_diseases_c"></textarea>
                        <?php else: ?>
                            <textarea class="form-control" rows="4" id="health_diseases_c" name="health_diseases_c"> <?php echo e($data['records_info'][0]->diseases); ?> </textarea>
                        <?php endif; ?>
                    </div>

                    <div class="form-group col-md-12">
                        <label for="nombre"><?php echo e(trans('message.ex.allergy')); ?></label>
                        <?php if(empty($data['records_info'][0]->allergy)): ?>
                            <textarea class="form-control" rows="4" id="health_allergy_c" name="health_allergy_c"></textarea>
                        <?php else: ?>
                            <textarea class="form-control" rows="4" id="health_allergy_c" name="health_allergy_c"> <?php echo e($data['records_info'][0]->allergy); ?> </textarea>
                        <?php endif; ?>
                    </div>

                </div>

            </div>

        </div>
    </div>

    <div class="col-md-12">
        <div class="box box-primary">

            <div class="box-header with-border">
                <h3 class="box-title"><i class="fa fa-info-circle"></i> <?php echo e(trans('message.ex.policy_data_title')); ?></h3>
            </div>

            <div class="box-body">

                <div class="form-group col-md-12">

                    <div class="form-group col-md-2">
                        <label for="language"><?php echo e(trans('message.ex.policy_type')); ?></label>
                            <select class="form-control" id="policy_type" name="policy_type_c">
                                <option value="">Ninguno</option>
                                <option value="Vida">Vida</option>
                                <option value="Gastos Médicos">Gastos Médicos</option>
                            </select>
                    </div>

                    <div class="form-group col-md-5">
                        <label for="language"><?php echo e(trans('message.ex.policy_company')); ?></label>
                        <input type="text" name="policy_company_c" id="policy_company" class="form-control">
                    </div>

                    <div class="form-group col-md-4">
                        <label for="language"><?php echo e(trans('message.ex.policy_number')); ?></label>
                        <input type="text" name="policy_number_c" id="policy_number" class="form-control">
                    </div>

                    <div class="form-group col-md-1">
                        <label for="spoken">Agregar:</label>
                        <button type="button" class="btn btn-success" id="save_record_policy_c">
                            <span class="fa fa-plus"></span>
                        </button>
                    </div>

                    <div class="form-group col-md-12" id="record_policy_div_c"></div>

                </div>

            </div>

        </div>
    </div>

    <div class="col-md-12">
        <div class="box box-primary">

            <div class="box-header with-border">
                <h3 class="box-title"><i class="fa fa-medkit"></i> <?php echo e(trans('message.ex.exam_medical_data_title')); ?></h3>
            </div>

            <div class="box-body">

                <div class="form-group col-md-12">

                    <div class="form-group col-md-7">
                        <label for="language"><?php echo e(trans('message.ex.medical_exam_reason')); ?></label>
                        <input type="text" name="medical_exam_reason" id="medical_exam_reason_c" class="form-control">
                    </div>

                    <div class="form-group col-md-2">
                        <label for="spoken"><?php echo e(trans('message.ex.medical_exam_date')); ?></label>
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                            </div>
                            <input type="text" class="form-control pull-right" id="medical_exam_date_c" name="medical_exam_date">
                        </div>
                    </div>

                    <div class="form-group col-md-2">
                        <label for="spoken"><?php echo e(trans('message.ex.medical_exam_file')); ?></label>
                        <input type="file" name="medicalExamFile[]" id="medical_exam_file" style="display: none">
                        <button type="button" id="btn_proof_medical_exam" class="btn btn-light text-white btn_proof_medical_exam btn-success form-control">
                            <i class="fa fa-file-pdf-o"></i> <?php echo e(trans('message.ex.search')); ?>

                        </button>
                    </div>

                    <div class="form-group col-md-1">
                        <label for="spoken">Agregar:</label>
                        <button type="button" class="btn btn-success" id="save_record_medical_exam_c">
                            <span class="fa fa-plus"></span>
                        </button>
                    </div>

                    <div class="form-group col-md-12" id="record_medical_exam_div_c"></div>

                </div>

            </div>

        </div>
    </div>

    <div class="col-md-12">
        <div class="box box-primary">

            <div class="box-header with-border">
                <h3 class="box-title"><i class="fa fa-users"></i> <?php echo e(trans('message.ex.emergency_contact_data_title')); ?></h3>
            </div>

            <div class="box-body">

                <div class="form-group col-md-12">

                    <div class="form-group col-md-7">
                        <label for="language"><?php echo e(trans('message.ex.emergency_contact_name')); ?></label>
                        <?php if(empty($data['records_info'][0]->contact_name1)): ?>
                            <input type="text" name="emergency_contact_name" id="emergency_contact_name" class="form-control">
                        <?php else: ?>
                            <input type="text" name="emergency_contact_name" id="emergency_contact_name" value="<?php echo e($data['records_info'][0]->contact_name1); ?>" class="form-control">
                        <?php endif; ?>
                        
                    </div>

                    <div class="form-group col-md-3">
                        <label for="language"><?php echo e(trans('message.ex.emergency_contact_phone')); ?></label>
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <?php if(empty($data['records_info'][0]->contact_phone1)): ?>
                                <input type="text" class="form-control" name="emergency_contact_phone" id="emergency_contact_phone">
                            <?php else: ?>
                                <input type="text" name="emergency_contact_phone" id="emergency_contact_phone" value="<?php echo e($data['records_info'][0]->contact_phone1); ?>" class="form-control">
                            <?php endif; ?>
                            
                        </div>
                    </div>

                    <div class="form-group col-md-2">
                        <label for="language"><?php echo e(trans('message.ex.emergency_contact_parent')); ?></label>
                        <select class="form-control" id="emergency_contact_parent" name="emergency_contact_parent">
                            <option value="">Ninguno</option>
                            <option value="Padre" <?php echo e(('Padre' == $data['records_info'][0]->contact_patent1) ? 'selected':''); ?> >Padre</option>
                            <option value="Madre" <?php echo e(('Madre' == $data['records_info'][0]->contact_patent1) ? 'selected':''); ?> >Madre</option>
                            <option value="Esposo" <?php echo e(('Esposo' == $data['records_info'][0]->contact_patent1) ? 'selected':''); ?> >Esposo</option>
                            <option value="Esposa" <?php echo e(('Esposa' == $data['records_info'][0]->contact_patent1) ? 'selected':''); ?> >Esposa</option>
                            <option value="Hijo" <?php echo e(('Hijo' == $data['records_info'][0]->contact_patent1) ? 'selected':''); ?> >Hijo</option>
                        </select>
                    </div>

                </div>

                <div class="form-group col-md-12">

                    <div class="form-group col-md-7">
                        <label for="language"><?php echo e(trans('message.ex.emergency_contact_name')); ?></label>
                        <?php if(empty($data['records_info'][0]->contact_name2)): ?>
                            <input type="text" name="emergency_contact_name2" id="emergency_contact_name2" class="form-control">
                        <?php else: ?>
                            <input type="text" name="emergency_contact_name2" id="emergency_contact_name2" value="<?php echo e($data['records_info'][0]->contact_name2); ?>" class="form-control">
                        <?php endif; ?>
                    </div>

                    <div class="form-group col-md-3">
                        <label for="language"><?php echo e(trans('message.ex.emergency_contact_phone')); ?></label>
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <?php if(empty($data['records_info'][0]->contact_phone2)): ?>
                                <input type="text" class="form-control" name="emergency_contact_phone2" id="emergency_contact_phone2">
                            <?php else: ?>
                                <input type="text" name="emergency_contact_phone2" id="emergency_contact_phone2" value="<?php echo e($data['records_info'][0]->contact_phone2); ?>" class="form-control">
                            <?php endif; ?>
                            
                        </div>
                    </div>

                    <div class="form-group col-md-2">
                        <label for="language"><?php echo e(trans('message.ex.emergency_contact_parent')); ?></label>
                        <select class="form-control" id="emergency_contact_parent2" name="emergency_contact_parent2">
                            <option value="">Ninguno</option>
                            <option value="Padre" <?php echo e(('Padre' == $data['records_info'][0]->contact_patent2) ? 'selected':''); ?> >Padre</option>
                            <option value="Madre" <?php echo e(('Madre' == $data['records_info'][0]->contact_patent2) ? 'selected':''); ?> >Madre</option>
                            <option value="Esposo" <?php echo e(('Esposo' == $data['records_info'][0]->contact_patent2) ? 'selected':''); ?> >Esposo</option>
                            <option value="Esposa" <?php echo e(('Esposa' == $data['records_info'][0]->contact_patent2) ? 'selected':''); ?> >Esposa</option>
                            <option value="Hijo" <?php echo e(('Hijo' == $data['records_info'][0]->contact_patent2) ? 'selected':''); ?> >Hijo</option>
                        </select>
                    </div>

                </div>

            </div>

            <div class="box-footer">
                <div class="row col-md-1 col-sm-12">
                    <button type="button" onclick="window.location.href = '<?php echo e(url('records')); ?>';" class="btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(trans('message.buttons.back')); ?></button>
                </div>
                <div class="row col-md-1 col-sm-12 col-md-offset-8">
                    <button type="submit" class="btn btn-success"><i class="fa fa-refresh"></i> <?php echo e(trans('message.buttons.edit')); ?></button>
                </div>
                <div class="row col-md-1 col-sm-12 col-md-offset-1">
                    <button type="button" onclick="window.location.href = '<?php echo e(url('records')); ?>';" class="btn btn-danger"><i class="fa fa-ban"></i> <?php echo e(trans('message.buttons.cancel')); ?></button>
                </div>
            </div>

        </div>
    </div>

    </form>
</div>
<?php /**PATH /Users/ericvargasrosas/Desktop/Laravel Projects/soysepanka/resources/views/expediente/partials/tab9.blade.php ENDPATH**/ ?>