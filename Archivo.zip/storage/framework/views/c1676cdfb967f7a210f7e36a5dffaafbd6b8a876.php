<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        <?php echo $__env->yieldContent('contentheader_title', 'Inicio'); ?>
        <small><?php echo $__env->yieldContent('contentheader_description'); ?></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> <?php echo $__env->yieldContent('contentheader_level', 'Inicio'); ?></a></li>
        <li class="active"><?php echo $__env->yieldContent('contentheader_level_here', 'Aquí'); ?></li>
    </ol>
</section>
<?php /**PATH /Users/ericvargasrosas/Desktop/Laravel Projects/soysepanka/resources/views/vendor/adminlte/layouts/partials/contentheader.blade.php ENDPATH**/ ?>