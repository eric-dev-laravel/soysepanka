<?php $__env->startSection('htmlheader_title'); ?>
	<?php echo e(trans('message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
	<?php echo e(trans('message.ma.admin_employee_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_level_here'); ?>
	<?php echo e(trans('message.ma.admin_employee_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<div class="container-fluid spark-screen">
    <div class="row">

        <div class="col-md-4 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-green"><i class="ion ion-ios-people-outline"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text"><?php echo e(trans('message.ma.newemployees')); ?></span>
                    <span class="info-box-number"><?php echo e(count($data['employees']['insertados'])); ?></span>
                </div>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text"><?php echo e(trans('message.ma.updatedemployees')); ?></span>
                    <span class="info-box-number"><?php echo e(count($data['employees']['actualizados'])); ?></span>
                </div>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-red"><i class="ion ion-ios-people-outline"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text"><?php echo e(trans('message.ma.deletedemployees')); ?></span>
                    <span class="info-box-number"><?php echo e(count($data['employees']['eliminados'])); ?></span>
                </div>
            </div>
        </div>

    </div>

	<div class="row">
        <div class="col-md-12">
            <div class="box">

                <div class="box-header with-border">
                    <h3 class="box-title"><i class="fa fa-download"></i> <?php echo e(trans('message.employee_importation')); ?></h3>

                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                            <i class="fa fa-times"></i></button>
                    </div>
                </div>

                <div class="box-body">

                    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

                        <div class="panel panel-success">
                            <div class="panel-heading" role="tab" id="headingOne">
                                <h4 class="panel-title" align="center">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne" style="color: black">
                                    <i class="fa fa-users"></i> <?php echo e(trans('message.ma.newemployees')); ?>

                                    </a>
                                </h4>
                            </div>
                            <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                <div class="panel-body">
                                    <table id="tableInsertar" class="table data-table table-row-border order-column">
                                        <?php if(count($data['employees']['insertados']) > 0): ?>
                                            <thead>
                                                <tr>
                                                    <?php $i = 0; ?>
                                                    <?php $__currentLoopData = $data['employees']['insertados']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            if($i == 0) {
                                                        ?>
                                                        <?php $__currentLoopData = array_keys($employee); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <th><?php echo e($header); ?></th>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $i++;
                                                            }
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $data['employees']['insertados']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <?php $__currentLoopData = array_keys($employee); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td><?php echo e($employee[$header]); ?></td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        <?php endif; ?>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="panel panel-warning">
                            <div class="panel-heading" role="tab" id="headingTwo">
                                <h4 class="panel-title" align="center">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" style="color: black">
                                        <i class="fa fa-users"></i> <?php echo e(trans('message.ma.updatedemployees')); ?>

                                    </a>
                                </h4>
                            </div>
                            <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                <div class="panel-body">
                                    <table id="tableActualizar" class="table data-table table-row-border order-column">
                                        <?php if(count($data['employees']['actualizados']) > 0): ?>
                                            <thead>
                                                <tr>
                                                    <?php $i = 0; ?>
                                                    <?php $__currentLoopData = $data['employees']['actualizados']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            if($i == 0) {
                                                        ?>
                                                        <?php $__currentLoopData = array_keys($employee); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <th><?php echo e($header); ?></th>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $i++;
                                                            }
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $data['employees']['actualizados']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <?php $__currentLoopData = array_keys($employee); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td><?php echo e($employee[$header]); ?></td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        <?php endif; ?>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="panel panel-danger">
                            <div class="panel-heading" role="tab" id="headingThree">
                                <h4 class="panel-title" align="center">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree" style="color: black">
                                        <i class="fa fa-users"></i> <?php echo e(trans('message.ma.deletedemployees')); ?>

                                    </a>
                                </h4>
                            </div>
                            <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                <div class="panel-body">
                                    <table id="tableEliminar" class="table data-table table-row-border order-column">
                                        <?php if(count($data['employees']['eliminados']) > 0): ?>
                                            <thead>
                                                <tr>
                                                    <?php $i = 0; ?>
                                                    <?php $__currentLoopData = $data['employees']['eliminados']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            if($i == 0) {
                                                        ?>
                                                        <?php $__currentLoopData = array_keys($employee->getAttributes()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <th><?php echo e($header); ?></th>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        <?php
                                                            $i++;
                                                            }
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $data['employees']['eliminados']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <?php $__currentLoopData = array_keys($employee->getAttributes()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td><?php echo e($employee[$header]); ?></td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        <?php endif; ?>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="row" style="margin-bottom: 30px">
                        <div class="col-md-offset-9">
                            <a class="btn btn-success" href="<?php echo e(url('employees-import-layout/' . $data['id_file'])); ?>"><?php echo e(trans('message.buttons.start')); ?></a>
                            <a class="btn btn-danger" href="<?php echo e(url('admin-employees')); ?>"><?php echo e(trans('message.buttons.cancel')); ?></a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-script'); ?>
    <script type="text/javascript">
        $(function () {
            var table = $('#tableInsertar').DataTable({
                processing: true,
                serverSide: false,
                responsive: true,
                scrollX: true,
                language: {
                    "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json",
                },
            });

            var table2 = $('.table-data').DataTable({
                processing: true,
                serverSide: false,
                responsive: true,
                scrollX: true,
                language: {
                    "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json",
                },
            });

            var table3 = $('#tableEliminar').DataTable({
                processing: true,
                serverSide: false,
                responsive: true,
                scrollX: true,
                language: {
                    "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json",
                },
            });
        });

    </script>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/administrador/Desktop/Laravel Projects/soysepanka-adminlte/resources/views/administracion/employees/showDataLayout.blade.php ENDPATH**/ ?>