<?php $__env->startSection('htmlheader_title'); ?>
	<?php echo e(trans('message.ci.birthday')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
	<?php echo e(trans('message.ci.birthday')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_level_here'); ?>
	<?php echo e(trans('message.ci.birthday')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
	<div class="container-fluid spark-screen">

        <div class="row">

            <div class="col-md-12">
                <div class="box box-solid">

                    <div class="box-body">
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                        </ol>
                        <div class="carousel-inner">

                            <div class="item active">
                                <img src="<?php echo e(asset('img/comunicacionInterna/banner_cumpleaños.png')); ?>" alt="First slide">

                                <!--<div class="carousel-caption">
                                    First Slide
                                </div>-->
                            </div>

                        </div>
                        <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                            <span class="fa fa-angle-left"></span>
                        </a>
                        <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                            <span class="fa fa-angle-right"></span>
                        </a>
                        </div>
                    </div>

                </div>
            </div>

        </div>

        <div class="row">

            <div class="box box-danger">

                <div class="box-header with-border">
                    <h3 class="box-title">Cumpleañeros!</h3>

                    <div class="box-tools pull-right">
                        <span class="label label-danger"><?php echo e(count($data['employee'])); ?> Personas</span>
                    </div>
                </div>

                <div class="box-body no-padding">

                    <ul class="users-list clearfix">
                        <?php $__currentLoopData = $data['employee']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <?php if(empty($employee->isUser)): ?>
                                    <img src="<?php echo e(asset('img/record/user.png')); ?>" style="width:128px;" alt="User Image">
                                <?php else: ?>
                                    <?php if(empty($employee->isUser->picture)): ?>
                                        <img src="<?php echo e(asset('img/record/user.png')); ?>" style="width:128px;" alt="User Image">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset($employee->isUser->url_path)); ?>" style="width:128px;" alt="User Image">
                                    <?php endif; ?>
                                <?php endif; ?>
                                <a class="users-list-name" href="#"><?php echo e($employee->nombre. ' ' . $employee->paterno. ' '. $employee->materno); ?></a>
                                <span class="users-list-date"><?php echo e($employee->nacimiento); ?></span>
                                <span class="users-list-hobbies">Hobbies</span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                </div>

            </div>

        </div>

	</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ericvargasrosas/Desktop/Laravel Projects/soysepanka/resources/views/comunicacionInterna/cumpleanios.blade.php ENDPATH**/ ?>