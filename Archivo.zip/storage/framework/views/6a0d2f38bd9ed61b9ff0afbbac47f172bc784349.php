<?php $__env->startSection('htmlheader_title'); ?>
	<?php echo e(trans('message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
	<?php echo e(trans('message.ma.admin_users_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_level_here'); ?>
	<?php echo e(trans('message.ma.admin_users_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

    <?php if($errors->any()): ?>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                <h4><i class="icon fa fa-ban"></i> <?php echo e(trans('message.modals.alert')); ?></h4>
                <?php echo e(trans('message.modals.alert_message_createuser')); ?>


                <a href="#" class="small-box-footer pull-right" data-toggle="modal" data-target="#modal-danger"><?php echo e(trans('message.modals.moreinfo')); ?></i></a>
            </div>

        </div>
    </div>
    <?php elseif(session()->has('success')): ?>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="alert alert-success alert-dismissible" id="success-alert">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                <h4><i class="icon fa fa-check"></i> <?php echo e(trans('message.modals.alert')); ?></h4>
                <?php echo e(trans('message.modals.success_message')); ?>

            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12">

            <div class="box">

                <div class="box-header with-border">
                    <h3 class="box-title"><i class="fa fa-user"></i> <?php echo e(trans('message.createuser')); ?></h3>

                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                            <i class="fa fa-times"></i></button>
                    </div>
                </div>

                <div class="box-body">
                    <div class="row col-md-12">
                        <form role="form" method="POST" action="<?php echo e(route('admin-users.store')); ?>" id="create">
                            <?php echo method_field('POST'); ?>

                            <?php echo csrf_field(); ?>


                            <div class="box box-primary">

                                <div class="box-header with-border">
                                    <h3 class="box-title"><i class="fa fa-pencil"></i> <?php echo e(trans('message.info_createusers')); ?></h3>
                                </div>

                                <div class="box-body">

                                    <div class="form-group col-md-4" style="display: none">
                                        <label for="nombre"><?php echo e(trans('message.datatables_headers.name')); ?></label>
                                        <input type="text" class="form-control" id="type" name="type" value="1">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="id_employee"><?php echo e(trans('message.datatables_headers.idemployee')); ?></label>
                                        <input type="text" class="form-control" id="id_employee" name="id_employee" placeholder="<?php echo trans('message.form_employee_holder.idemployee'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="nombre"><?php echo e(trans('message.datatables_headers.name')); ?></label>
                                        <input type="text" required class="form-control" id="name" name="name" placeholder="<?php echo trans('message.form_employee_holder.name'); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="email"><?php echo e(trans('message.datatables_headers.username')); ?></label>
                                        <input type="email" required class="form-control" id="email" name="email" placeholder="<?php echo trans('message.form_employee_holder.username'); ?>"
                                        class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" autocomplete="email">
                                    </div>

                                    <div class="form-group has-feedback col-md-4">
                                        <label for="password"><?php echo e(trans('message.datatables_headers.password')); ?></label>
                                        <div class="input-group">
                                            <input type="password" required class="form-control" placeholder="<?php echo e(trans('message.form_employee_holder.password')); ?>" name="password" id="password"/>
                                            <span class="input-group-btn">
                                                <button id="show_password" class="btn btn-primary" type="button" onclick="mostrarPassword()">
                                                    <span class="fa fa-eye-slash icon"></span> 
                                                </button>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="form-group has-feedback col-md-4">
                                        <label for="password"><?php echo e(trans('message.datatables_headers.password')); ?></label>
                                        <div class="input-group">
                                            <input type="password" required class="form-control" placeholder="<?php echo e(trans('message.form_employee_holder.retrypassword')); ?>" name="password_confirmation" id="password_confirmation"/>
                                            <span class="input-group-btn">
                                                <button id="show_retrypassword" class="btn btn-primary" type="button" onclick="mostrarRePassword()">
                                                    <span class="fa fa-eye-slash reicon"></span> 
                                                </button>
                                            </span>
                                        </div>
                                    </div>

                                </div>

                                <div class="box-footer">
                                    <div class="row col-md-1 col-sm-12">
                                        <button type="button" onclick="window.location.href = '<?php echo e(url('admin-users')); ?>';" class="btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(trans('message.buttons.back')); ?></button>
                                    </div>
                                    <div class="row col-md-1 col-sm-12 col-md-offset-8">
                                        <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> <?php echo e(trans('message.buttons.create')); ?></button>
                                    </div>
                                    <div class="row col-md-1 col-sm-12 col-md-offset-1">
                                        <button type="button" onclick="window.location.href = '<?php echo e(url('admin-users')); ?>';" class="btn btn-danger"><i class="fa fa-ban"></i> <?php echo e(trans('message.buttons.cancel')); ?></button>
                                    </div>
                                </div>

                            </div>

                        </form>
                    </div>
                </div>

            </div>
        </div>

        <div class="modal modal-danger fade" id="modal-danger" style="display: none;">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title"><?php echo e(trans('message.modals.alert')); ?></h4>
                    </div>

                    <div class="modal-body">
                        <?php if($errors->any()): ?>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline pull-left" data-dismiss="modal"><?php echo e(trans('message.buttons.close')); ?></button>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-script'); ?>
    <script type="text/javascript">
        setTimeout(function() {
            $('#success-alert').fadeOut('fast');
        }, 5000); // <-- time in milliseconds

        function mostrarPassword(){
            var cambio = document.getElementById("password");
            if(cambio.type == "password"){
                cambio.type = "text";
                $('.icon').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
            }else{
                cambio.type = "password";
                $('.icon').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
            }
        } 
        
        $(document).ready(function () {
            //CheckBox mostrar contraseña
            $('#ShowPassword').click(function () {
                $('#Password').attr('type', $(this).is(':checked') ? 'text' : 'password');
            });
        });

        function mostrarRePassword(){
            var cambio = document.getElementById("password_confirmation");
            if(cambio.type == "password"){
                cambio.type = "text";
                $('.reicon').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
            }else{
                cambio.type = "password";
                $('.reicon').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
            }
        } 
        
        $(document).ready(function () {
            //CheckBox mostrar contraseña
            $('#ShowRePassword').click(function () {
                $('#Password').attr('type', $(this).is(':checked') ? 'text' : 'password');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ericvargasrosas/Desktop/Laravel Projects/soysepanka/resources/views/administracion/users/create.blade.php ENDPATH**/ ?>