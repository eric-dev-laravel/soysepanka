<?php $__env->startSection('htmlheader_title'); ?>
	<?php echo e(trans('message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
	<?php echo e(trans('message.ma.admin_marks_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_level_here'); ?>
	<?php echo e(trans('message.ma.admin_marks_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <?php if($errors->any()): ?>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                <h4><i class="icon fa fa-bookmark-o"></i> <?php echo e(trans('message.modals.alert')); ?></h4>
                <?php echo e(trans('message.modals.alert_message_createuser')); ?>


                <a href="#" class="small-box-footer pull-right" data-toggle="modal" data-target="#modal-danger"><?php echo e(trans('message.modals.moreinfo')); ?></i></a>
            </div>

        </div>
    </div>
    <?php elseif(session()->has('success')): ?>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="alert alert-success alert-dismissible" id="success-alert">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                <h4><i class="icon fa fa-check"></i> <?php echo e(trans('message.modals.alert')); ?></h4>
                <?php echo e(trans('message.modals.success_message')); ?>

            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12">

            <div class="box box-primary box-solid">

                <div class="box-header with-border">
                    <h3 class="box-title"><i class="fa fa-hand-o-up"></i> <?php echo e(trans('message.options')); ?></h3>
                </div>

                <div class="box-body">

                    <div class="row col-md-3 col-sm-12 col-md-offset-1">
                        <?php if($info_direction['direction'][0]->deleted_at): ?>
                            <button type="button" class="btn btn-block btn-success" data-toggle="modal" data-target="#modal-active-employee"><i class="fa fa-check-square"></i> <?php echo e(trans('message.buttons.active')); ?></button>
                        <?php else: ?>
                            <button type="button" class="btn btn-block btn-danger" data-toggle="modal" data-target="#modal-unactive-employee"><i class="fa fa-minus-square"></i> <?php echo e(trans('message.buttons.unactive')); ?></button>
                        <?php endif; ?>
                    </div>

                </div>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">

            <div class="box">

                <div class="box-header with-border">
                    <h3 class="box-title"><i class="fa fa-bookmark-o"></i> <?php echo e(trans('message.editdirection')); ?></h3>

                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                            <i class="fa fa-times"></i></button>
                    </div>
                </div>

                <div class="box-body">
                    <div class="row col-md-12">
                        <form role="form" method="POST" action="<?php echo e(route('admin-marks.update',$info_direction['direction'][0]->id)); ?>" id="update">
                            <?php echo method_field('PUT'); ?>

                            <?php echo csrf_field(); ?>


                            <div class="box box-primary">

                                <div class="box-header with-border">
                                    <h3 class="box-title"><i class="fa fa-pencil"></i> <?php echo e(trans('message.info_createmarks')); ?></h3>
                                </div>

                                <div class="box-body">

                                    

                                    <div class="form-group col-md-12">
                                        <label for="nombre"><?php echo e(trans('message.datatables_headers.mark')); ?></label>
                                        <input type="text" required class="form-control" id="name" name="name" value="<?php echo e($info_direction['direction'][0]->name); ?>" placeholder="<?php echo e(trans('message.form_employee_holder.mark')); ?>">
                                    </div>

                                    <div class="form-group col-md-12">
                                        <label for="nombre"><?php echo e(trans('message.datatables_headers.description')); ?></label>
                                        <textarea class="form-control" rows="4" id="description" name="description" placeholder="<?php echo e(trans('message.form_employee_holder.info_direction')); ?>"> <?php echo e($info_direction['direction'][0]->description); ?> </textarea>
                                    </div>

                                </div>

                                <div class="box-footer">
                                    <div class="row col-md-1 col-sm-12">
                                        <button type="button" onclick="window.location.href = '<?php echo e(url('admin-marks')); ?>';" class="btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(trans('message.buttons.back')); ?></button>
                                    </div>
                                    <div class="row col-md-1 col-sm-12 col-md-offset-8">
                                        <button type="submit" class="btn btn-success"><i class="fa fa-refresh"></i> <?php echo e(trans('message.buttons.edit')); ?></button>
                                    </div>
                                    <div class="row col-md-1 col-sm-12 col-md-offset-1">
                                        <button type="button" onclick="window.location.href = '<?php echo e(url('admin-marks')); ?>';" class="btn btn-danger"><i class="fa fa-ban"></i> <?php echo e(trans('message.buttons.cancel')); ?></button>
                                    </div>
                                </div>

                            </div>

                        </form>
                    </div>
                </div>

            </div>
        </div>

        <div class="modal modal-danger fade" id="modal-danger" style="display: none;">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title"><?php echo e(trans('message.modals.alert')); ?></h4>
                    </div>

                    <div class="modal-body">
                        <?php if($errors->any()): ?>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline pull-left" data-dismiss="modal"><?php echo e(trans('message.buttons.close')); ?></button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal modal-danger fade" id="modal-unactive-employee" style="display: none;">
            <form class="form" action="<?php echo e(route('admin-marks.destroy' , $info_direction['direction'][0]->id)); ?>" method="POST">
                <?php echo method_field('DELETE'); ?>

                <?php echo csrf_field(); ?>

                <div class="modal-dialog">
                    <div class="modal-content">

                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                            <h4 class="modal-title"><?php echo e(trans('message.modals.alert')); ?></h4>
                        </div>

                        <div class="modal-body">
                            <?php echo e(trans('message.modals.dangermessageemployee')); ?>

                            <?php echo e(trans('message.modals.questioncontinue')); ?>

                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline pull-left" data-dismiss="modal"><?php echo e(trans('message.buttons.close')); ?></button>
                            <button type="submit" class="btn btn-outline"><?php echo e(trans('message.buttons.unactive')); ?></button>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <div class="modal modal-success fade" id="modal-active-employee" style="display: none;">
                <div class="modal-dialog">
                    <div class="modal-content">

                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                            <h4 class="modal-title"><?php echo e(trans('message.modals.alert')); ?></h4>
                        </div>

                        <div class="modal-body">
                            <?php echo e(trans('message.modals.warningmessageemployee')); ?>

                            <?php echo e(trans('message.modals.questioncontinue')); ?>

                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline pull-left" data-dismiss="modal"><?php echo e(trans('message.buttons.close')); ?></button>
                            <button type="button" onclick="window.location.href = '<?php echo e(url('active-mark/'.$info_direction['direction'][0]->id.'')); ?>';" class="btn btn-outline"><?php echo e(trans('message.buttons.active')); ?></button>
                        </div>
                    </div>
                </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-script'); ?>
    <script type="text/javascript">
        setTimeout(function() {
            $('#success-alert').fadeOut('fast');
        }, 5000); // <-- time in milliseconds
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ericvargasrosas/Desktop/Laravel Projects/soysepanka/resources/views/administracion/marks/edit.blade.php ENDPATH**/ ?>