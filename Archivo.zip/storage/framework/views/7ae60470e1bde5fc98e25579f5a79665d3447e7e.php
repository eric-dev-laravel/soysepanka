<?php $__env->startSection('htmlheader_title'); ?>
	<?php echo e(trans('message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
	<?php echo e(trans('message.ma.admin_directions_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_level_here'); ?>
	<?php echo e(trans('message.ma.admin_directions_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <?php if($errors->any()): ?>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                <h4><i class="icon fa fa-arrows"></i> <?php echo e(trans('message.modals.alert')); ?></h4>
                <?php echo e(trans('message.modals.alert_message_createuser')); ?>


                <a href="#" class="small-box-footer pull-right" data-toggle="modal" data-target="#modal-danger"><?php echo e(trans('message.modals.moreinfo')); ?></i></a>
            </div>

        </div>
    </div>
    <?php elseif(session()->has('success')): ?>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="alert alert-success alert-dismissible" id="success-alert">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                <h4><i class="icon fa fa-check"></i> <?php echo e(trans('message.modals.alert')); ?></h4>
                <?php echo e(trans('message.modals.success_message')); ?>

            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12">

            <div class="box">

                <div class="box-header with-border">
                    <h3 class="box-title"><i class="fa fa-arrows"></i> <?php echo e(trans('message.createdirection')); ?></h3>

                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                            <i class="fa fa-times"></i></button>
                    </div>
                </div>

                <div class="box-body">
                    <div class="row col-md-12">
                        <form role="form" method="POST" action="<?php echo e(route('admin-directions.store')); ?>" id="create">
                            <?php echo method_field('POST'); ?>

                            <?php echo csrf_field(); ?>


                            <div class="box box-primary">

                                <div class="box-header with-border">
                                    <h3 class="box-title"><i class="fa fa-pencil"></i> <?php echo e(trans('message.info_createdirections')); ?></h3>
                                </div>

                                <div class="box-body">

                                    

                                    <div class="form-group col-md-12">
                                        <label for="nombre"><?php echo e(trans('message.datatables_headers.direction')); ?></label>
                                        <input type="text" required class="form-control" id="name" name="name" placeholder="<?php echo e(trans('message.form_employee_holder.direction')); ?>">
                                    </div>

                                    <div class="form-group col-md-12">
                                        <label for="nombre"><?php echo e(trans('message.datatables_headers.description')); ?></label>
                                        <textarea class="form-control" rows="4" id="description" name="description" placeholder="<?php echo e(trans('message.form_employee_holder.info_direction')); ?>"></textarea>
                                    </div>

                                </div>

                                <div class="box-footer">
                                    <div class="row col-md-1 col-sm-12">
                                        <button type="button" onclick="window.location.href = '<?php echo e(url('admin-directions')); ?>';" class="btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(trans('message.buttons.back')); ?></button>
                                    </div>
                                    <div class="row col-md-1 col-sm-12 col-md-offset-8">
                                        <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> <?php echo e(trans('message.buttons.create')); ?></button>
                                    </div>
                                    <div class="row col-md-1 col-sm-12 col-md-offset-1">
                                        <button type="button" onclick="window.location.href = '<?php echo e(url('admin-directions')); ?>';" class="btn btn-danger"><i class="fa fa-ban"></i> <?php echo e(trans('message.buttons.cancel')); ?></button>
                                    </div>
                                </div>

                            </div>

                        </form>
                    </div>
                </div>

            </div>
        </div>

        <div class="modal modal-danger fade" id="modal-danger" style="display: none;">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title"><?php echo e(trans('message.modals.alert')); ?></h4>
                    </div>

                    <div class="modal-body">
                        <?php if($errors->any()): ?>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline pull-left" data-dismiss="modal"><?php echo e(trans('message.buttons.close')); ?></button>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-script'); ?>
    <script type="text/javascript">

        setTimeout(function() {
            $('#success-alert').fadeOut('fast');
        }, 5000); // <-- time in milliseconds

        /*$('#id_enterprise').change(function(){
            var id = $(this).val();
            getMarks(id);
        });

        function getMarks(id){
            $.ajax({
                url: "<?php echo e(url('marks')); ?>/"+id,
                Type:'GET',
                success: function(result){

                    $('#id_mark').empty();
                    $('#id_mark').append($('<option>', {
                        value: '',
                        text : 'Sin Marca'
                    }));
                    $.each(result, function(i, item){
                        $('#id_mark').append($('<option>', {
                            value: item.id,
                            text : item.name
                        }));
                    })

                }
            });
        }*/
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/administrador/Desktop/Laravel Projects/soysepanka-adminlte/resources/views/administracion/directions/create.blade.php ENDPATH**/ ?>