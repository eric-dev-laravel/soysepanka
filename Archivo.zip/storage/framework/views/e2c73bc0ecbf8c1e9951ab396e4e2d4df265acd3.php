<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        <a href="https://sepankasuite.com"></a><b>Sepankasuite</b></a>. <?php echo e(trans('message.descriptionpackage')); ?>

    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2020 <a href="http://sepankasuite.com">Sepankasuite</a>.</strong> <?php echo e(trans('message.createdby')); ?> <a href="http://sepankasuite.con">Sepankasuite</a>.
</footer>
<?php /**PATH /Users/administrador/Desktop/Laravel Projects/soysepanka-adminlte/resources/views/vendor/adminlte/layouts/partials/footer.blade.php ENDPATH**/ ?>